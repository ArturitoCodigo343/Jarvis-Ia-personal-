package com.jarvisai.personal

import android.Manifest
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.UUID

private val Night = Color(0xFF07111F)
private val Panel = Color(0xFF101F32)
private val Cyan = Color(0xFF55DFFF)
private val Soft = Color(0xFFB8C9DA)

data class JarvisEvent(val id: String, val title: String, val day: Int, val hour: Int, val minute: Int, val advance: Int = 30) {
    fun dayName(): String = listOf("", "domingo", "lunes", "martes", "miércoles", "jueves", "viernes", "sábado").getOrElse(day) { "día" }
    fun timeText(): String = String.format(Locale("es", "ES"), "%02d:%02d", hour, minute)
}

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private val askNotification = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            askNotification.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        setContent { JarvisApp(this, onSpeak = { speak(it) }) }
    }
    override fun onInit(status: Int) { if (status == TextToSpeech.SUCCESS) tts?.language = Locale("es", "ES") }
    private fun speak(text: String) { tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis-speech") }
    override fun onDestroy() { tts?.shutdown(); super.onDestroy() }
}

@Composable
private fun JarvisApp(context: Context, onSpeak: (String) -> Unit) {
    var tab by remember { mutableStateOf(0) }
    var events by remember { mutableStateOf(loadEvents(context)) }
    var showAdd by remember { mutableStateOf(false) }
    var title by remember { mutableStateOf("") }
    var day by remember { mutableIntStateOf(Calendar.TUESDAY) }
    var hour by remember { mutableStateOf("16") }
    var minute by remember { mutableStateOf("00") }
    var advance by remember { mutableStateOf("30") }
    var message by remember { mutableStateOf("") }
    var chatReply by remember { mutableStateOf("Estoy listo para ayudarte. Puedes guardar horarios y configurar avisos.") }

    MaterialTheme(colorScheme = darkColorScheme(primary = Cyan, background = Night, surface = Panel, onBackground = Color.White, onSurface = Color.White)) {
        Scaffold(containerColor = Night, bottomBar = {
            NavigationBar(containerColor = Panel, contentColor = Cyan) {
                NavigationBarItem(selected = tab == 0, onClick = { tab = 0 }, icon = { Icon(Icons.Default.SmartToy, null) }, label = { Text("Inicio") })
                NavigationBarItem(selected = tab == 1, onClick = { tab = 1 }, icon = { Icon(Icons.Default.CalendarMonth, null) }, label = { Text("Mi día") })
                NavigationBarItem(selected = tab == 2, onClick = { tab = 2 }, icon = { Icon(Icons.Default.Settings, null) }, label = { Text("Ajustes") })
            }
        }) { pad ->
            Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Night, Color(0xFF0B1B2E)))).padding(pad).padding(18.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(42.dp).background(Cyan.copy(alpha = .14f), CircleShape), contentAlignment = Alignment.Center) { Icon(Icons.Default.SmartToy, null, tint = Cyan, modifier = Modifier.size(26.dp)) }
                    Spacer(Modifier.width(10.dp))
                    Column { Text("JARVIS AI", fontSize = 21.sp, fontWeight = FontWeight.Bold, color = Color.White); Text("ASISTENTE PERSONAL", fontSize = 10.sp, color = Cyan, letterSpacing = 2.sp) }
                }
                Spacer(Modifier.height(20.dp))
                when (tab) {
                    0 -> {
                        Text("Buenos días, señor Arturo", fontSize = 23.sp, fontWeight = FontWeight.SemiBold)
                        Text("¿En qué puedo ayudarle?", color = Soft)
                        Spacer(Modifier.height(18.dp))
                        Box(Modifier.fillMaxWidth().height(150.dp).background(Brush.radialGradient(listOf(Color(0xFF16506A), Panel)), RoundedCornerShape(24.dp)), contentAlignment = Alignment.Center) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Box(Modifier.size(76.dp).background(Cyan.copy(alpha = .16f), CircleShape), contentAlignment = Alignment.Center) { Icon(Icons.Default.Mic, null, tint = Cyan, modifier = Modifier.size(36.dp)) }
                                Spacer(Modifier.height(8.dp)); Text("JARVIS está listo", color = Cyan, fontWeight = FontWeight.Medium)
                            }
                        }
                        Spacer(Modifier.height(14.dp))
                        OutlinedTextField(value = message, onValueChange = { message = it }, modifier = Modifier.fillMaxWidth(), placeholder = { Text("Escribe a Jarvis…", color = Soft) }, shape = RoundedCornerShape(16.dp), singleLine = true)
                        Button(onClick = {
                            val q = message.trim()
                            chatReply = if (q.isBlank()) "Dígame qué necesita, señor Arturo." else respondTo(q, events)
                            onSpeak(chatReply); message = ""
                        }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Cyan, contentColor = Night)) { Text("Hablar con JARVIS", fontWeight = FontWeight.Bold) }
                        Spacer(Modifier.height(12.dp))
                        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) { Column(Modifier.padding(14.dp)) { Text("RESPUESTA DE JARVIS", color = Cyan, fontSize = 11.sp, fontWeight = FontWeight.Bold); Spacer(Modifier.height(5.dp)); Text(chatReply, color = Color.White) } }
                        Spacer(Modifier.height(12.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            QuickTile("Mi horario", "${events.size} sesiones", Modifier.weight(1f)) { tab = 1 }
                            QuickTile("Añadir evento", "Nuevo aviso", Modifier.weight(1f)) { showAdd = true }
                        }
                    }
                    1 -> {
                        Text("Mi calendario", fontSize = 25.sp, fontWeight = FontWeight.Bold)
                        Text("Sesiones semanales y avisos anticipados", color = Soft)
                        Spacer(Modifier.height(12.dp))
                        Button(onClick = { showAdd = true }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Cyan, contentColor = Night)) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(6.dp)); Text("Añadir horario") }
                        Spacer(Modifier.height(10.dp))
                        if (events.isEmpty()) Text("Todavía no hay horarios. Añade una clase o actividad.", color = Soft, modifier = Modifier.padding(8.dp))
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                            items(events.sortedWith(compareBy<JarvisEvent> { it.day }.thenBy { it.hour }.thenBy { it.minute }), key = { it.id }) { e ->
                                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
                                    Row(Modifier.fillMaxWidth().padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Column(Modifier.weight(1f)) { Text(e.title, fontWeight = FontWeight.SemiBold, fontSize = 16.sp); Text("${e.dayName().replaceFirstChar { it.uppercase() }} · ${e.timeText()}", color = Cyan); Text("Aviso ${e.advance} min antes", color = Soft, fontSize = 12.sp) }
                                        TextButton(onClick = { events = events.filterNot { it.id == e.id }; saveEvents(context, events); cancelReminder(context, e.id) }) { Text("Eliminar", color = Color(0xFFFF9B9B)) }
                                    }
                                }
                            }
                        }
                    }
                    else -> {
                        Text("Ajustes", fontSize = 25.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(12.dp))
                        Card(colors = CardDefaults.cardColors(containerColor = Panel)) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("Voz", color = Cyan, fontWeight = FontWeight.Bold); Text("La voz de prueba usa la síntesis de voz instalada en Android.", color = Soft)
                            Button(onClick = { onSpeak("Buenas tardes, señor Arturo. Soy JARVIS. Los avisos de calendario están preparados en esta versión inicial.") }, colors = ButtonDefaults.buttonColors(containerColor = Cyan, contentColor = Night)) { Text("Probar voz") }
                            Divider(color = Color(0xFF263B51)); Text("Avisos", color = Cyan, fontWeight = FontWeight.Bold); Text("Permite las notificaciones de JARVIS y evita que el sistema la ponga en suspensión si quieres mejorar la puntualidad de los avisos.", color = Soft)
                            Divider(color = Color(0xFF263B51)); Text("Privacidad", color = Cyan, fontWeight = FontWeight.Bold); Text("Los horarios de esta versión se guardan localmente en el móvil. La IA en línea y las integraciones de WhatsApp todavía no están conectadas.", color = Soft)
                        } }
                    }
                }
            }
        }
        if (showAdd) AlertDialog(
            onDismissRequest = { showAdd = false }, containerColor = Panel,
            title = { Text("Nuevo horario", color = Color.White) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Actividad (p. ej. Inglés)") }, singleLine = true)
                    Text("Día de la semana", color = Soft)
                    var dayMenu by remember { mutableStateOf(false) }
                    Box {
                        OutlinedButton(onClick = { dayMenu = true }) { Text(dayLabel(day)) }
                        DropdownMenu(expanded = dayMenu, onDismissRequest = { dayMenu = false }) {
                            (listOf(Calendar.MONDAY, Calendar.TUESDAY, Calendar.WEDNESDAY, Calendar.THURSDAY, Calendar.FRIDAY, Calendar.SATURDAY, Calendar.SUNDAY)).forEach { d -> DropdownMenuItem(text = { Text(dayLabel(d)) }, onClick = { day = d; dayMenu = false }) }
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = hour, onValueChange = { hour = it.filter(Char::isDigit).take(2) }, label = { Text("Hora (0–23)") }, modifier = Modifier.weight(1f), singleLine = true)
                        OutlinedTextField(value = minute, onValueChange = { minute = it.filter(Char::isDigit).take(2) }, label = { Text("Minutos") }, modifier = Modifier.weight(1f), singleLine = true)
                    }
                    OutlinedTextField(value = advance, onValueChange = { advance = it.filter(Char::isDigit).take(3) }, label = { Text("Avisar antes (minutos)") }, singleLine = true)
                }
            },
            confirmButton = { TextButton(onClick = {
                val h = hour.toIntOrNull(); val m = minute.toIntOrNull(); val a = advance.toIntOrNull() ?: 30
                if (title.isNotBlank() && h != null && h in 0..23 && m != null && m in 0..59 && a in 0..1440) {
                    val e = JarvisEvent(UUID.randomUUID().toString(), title.trim(), day, h, m, a)
                    events = events + e; saveEvents(context, events); scheduleReminder(context, e)
                    title = ""; hour = "16"; minute = "00"; advance = "30"; showAdd = false
                }
            }) { Text("Guardar") } },
            dismissButton = { TextButton(onClick = { showAdd = false }) { Text("Cancelar") } }
        )
    }
}

@Composable private fun QuickTile(title: String, subtitle: String, modifier: Modifier = Modifier, action: () -> Unit) {
    Card(onClick = action, modifier = modifier, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) { Column(Modifier.padding(14.dp)) { Text(title, color = Color.White, fontWeight = FontWeight.SemiBold); Text(subtitle, color = Cyan, fontSize = 12.sp) } }
}

private fun dayLabel(day: Int) = when (day) { Calendar.MONDAY -> "Lunes"; Calendar.TUESDAY -> "Martes"; Calendar.WEDNESDAY -> "Miércoles"; Calendar.THURSDAY -> "Jueves"; Calendar.FRIDAY -> "Viernes"; Calendar.SATURDAY -> "Sábado"; else -> "Domingo" }

private fun saveEvents(context: Context, events: List<JarvisEvent>) {
    val arr = JSONArray(); events.forEach { e -> arr.put(JSONObject().put("id", e.id).put("title", e.title).put("day", e.day).put("hour", e.hour).put("minute", e.minute).put("advance", e.advance)) }
    context.getSharedPreferences("jarvis", Context.MODE_PRIVATE).edit().putString("events", arr.toString()).apply()
}
private fun loadEvents(context: Context): List<JarvisEvent> = runCatching {
    val arr = JSONArray(context.getSharedPreferences("jarvis", Context.MODE_PRIVATE).getString("events", "[]"))
    (0 until arr.length()).map { i -> arr.getJSONObject(i).let { JarvisEvent(it.getString("id"), it.getString("title"), it.getInt("day"), it.getInt("hour"), it.getInt("minute"), it.optInt("advance", 30)) } }
}.getOrDefault(emptyList())

private fun scheduleReminder(context: Context, event: JarvisEvent) {
    val now = Calendar.getInstance()
    val target = Calendar.getInstance().apply {
        set(Calendar.DAY_OF_WEEK, event.day); set(Calendar.HOUR_OF_DAY, event.hour); set(Calendar.MINUTE, event.minute); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        add(Calendar.MINUTE, -event.advance)
        if (timeInMillis <= now.timeInMillis) add(Calendar.DAY_OF_YEAR, 7)
    }
    val intent = Intent(context, ReminderReceiver::class.java).putExtra("title", event.title).putExtra("time", event.timeText()).putExtra("id", event.id)
    val pi = PendingIntent.getBroadcast(context, event.id.hashCode(), intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
    alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, target.timeInMillis, pi)
}
private fun cancelReminder(context: Context, id: String) {
    val pi = PendingIntent.getBroadcast(context, id.hashCode(), Intent(context, ReminderReceiver::class.java), PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE)
    if (pi != null) (context.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pi)
}
private fun respondTo(question: String, events: List<JarvisEvent>): String {
    val q = question.lowercase(Locale("es", "ES"))
    if (listOf("horario", "inglés", "ingles", "mañana", "hoy", "clase", "qué tengo", "que tengo").any { it in q }) {
        val matches = events.filter { e -> (q.contains("inglés") || q.contains("ingles")) && e.title.contains("ingl", true) || q.contains("horario") || q.contains("clase") || q.contains("qué tengo") || q.contains("que tengo") }
        return if (matches.isEmpty()) "Todavía no encuentro ese evento en su calendario, señor Arturo. Puede añadirlo en Mi día." else "En el calendario tengo: " + matches.joinToString("; ") { "${it.title}, ${it.dayName()} a las ${it.timeText()}" } + "."
    }
    return "En esta versión inicial puedo guardar y consultar horarios. El cerebro de IA completo aún no está conectado, señor Arturo."
}
