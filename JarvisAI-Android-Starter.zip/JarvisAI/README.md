# JARVIS AI — Android starter (0.1.0)

This is a **first native Android starter**, not the finished AI assistant. It provides a home-screen app icon, a futuristic Compose UI, locally saved weekly events, one reminder scheduled per event, notification permission request, and Android text-to-speech for test phrases.

## Build an APK from a phone using GitHub Actions
1. On your phone, open GitHub and create a new **empty repository** named `JarvisAI` (do not add a README or license if you plan to upload this ZIP contents directly).
2. Extract this ZIP on your phone, or use GitHub's upload-files screen and upload the extracted files/folders preserving the directory structure.
3. In the repository, open **Actions** and allow workflows if GitHub asks.
4. Select **Build JARVIS AI APK** → **Run workflow**.
5. Open the completed workflow run, scroll to **Artifacts**, and download `JARVIS-AI-debug-APK`. Extract it and install `app-debug.apk` on the Samsung. Android may ask you to allow installs from the browser/files app; only allow it for the file you built yourself.

## Current limits (important)
- This is an initial scaffold; it has not been built or device-tested in this environment.
- It does **not** yet connect to a remote LLM/API. The chat area is an explicit placeholder, not a full AI brain.
- It does not yet provide wake-word listening, WhatsApp reading/sending, phone-call automation, OCR, cloud sync, or robust recurring weekly alarm rescheduling.
- The initial reminder implementation schedules the next upcoming occurrence when an event is saved. Repeating every week and rescheduling after reboot/time changes must be added and tested before relying on it for important appointments.
- Android/Samsung battery settings and notification permissions affect background reliability. This starter cannot guarantee voice announcements with the screen off.
- No API keys are included. Do not put secret API keys directly in a mobile app.

## Technical
- Native Kotlin + Jetpack Compose; min SDK 26.
- Application ID: `com.jarvisai.personal`.
